data = (1,)

#如果元组只有一个数时，必须加个逗号，否则不是元组
print(data)
print(type(data))
